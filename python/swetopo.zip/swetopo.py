import swecoord
import math
import os
import android
import time
import urllib
droid=android.Android()

import termios, sys
TERMIOS = termios

def getkey():
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    new = termios.tcgetattr(fd)
    new[3] = new[3] & ~TERMIOS.ICANON & ~TERMIOS.ECHO
    new[6][TERMIOS.VMIN] = 1
    new[6][TERMIOS.VTIME] = 0
    termios.tcsetattr(fd, TERMIOS.TCSANOW, new)
    c = None
    try:
        c = os.read(fd, 1)
    finally:
        termios.tcsetattr(fd, TERMIOS.TCSAFLUSH, old)
    return c


karttoja='/mnt/sdcard/karttoja/'
ruotsi=karttoja+'ruotsi/'
jemma=ruotsi
kartanpaikka=karttoja+'ruotsi.html'
kursori=karttoja+'kursori.png'
asetukset=ruotsi+'asetukset.py'

Tsize_orig=1024
Tsize_pic=256

def BBOX(lx,dy,rx,uy):
    urli = 'http://kso.lantmateriet.se/wmsproxy/wmsproxy?LAYERS=terrangkartan&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&STYLES=&EXCEPTIONS=application%%2Fvnd.ogc.se_inimage&FORMAT=image%%2Fjpeg&SRS=EPSG%%3A3006&BBOX=%d,%d,%d,%d&WIDTH=%d&HEIGHT=%d' % (lx,dy,rx,uy,Tsize_pic,Tsize_pic)
    jemma2=jemma+str(lx)
    if ONLINE and not os.path.exists(jemma2):
                os.makedirs(jemma2)
    nimi = jemma2+'/'+str(dy)+".jpg"
    if ONLINE and not os.path.exists(nimi):
        print 'urlretrieve'
        urllib.urlretrieve( urli , nimi )
    return nimi        

def BBOX1(lx,dy):
    return BBOX(lx,dy,lx+Tsize_orig,dy+Tsize_orig)

def kartta2(lx,dy,rx,uy,korjaus,lalo):  
    f=open(kartanpaikka,'w')
    f.write('<html>\n')
    xc=int((rx-lx)/Tsize_orig)
    yc=int((uy-dy)/Tsize_orig)
    yhtml=0
    ky=uy-Tsize_orig
    for y in range(0,yc):
        xhtml=0
        kx=lx
        for x in range(0,xc):
            tiili=BBOX1(kx,ky)
            f.write('<div style="position: absolute; left:%d; top:%d">\n'%(xhtml,yhtml))
            if os.path.exists(tiili):
                f.write('<img src="'+tiili+'">\n')
            else:
                la2,lo2=swecoord.sweTowgs(ky+Tsize_orig,kx)
                f.write(str(round(la2,4))+' '+str(round(lo2,4))+'\n')
            f.write('</div>\n')
            kx=kx+Tsize_orig
            xhtml=xhtml+Tsize_pic
        ky=ky-Tsize_orig
        yhtml=yhtml+Tsize_pic
    f.write('<div style="position: absolute; left:%d; top:%d">\n'%((xc/2)*Tsize_pic+korjaus[0]-50,round((yc+1)/2)*Tsize_pic-korjaus[1]-50))
    f.write('<img src="'+kursori+'">\n')
    f.write('</div>\n')
    f.write('<div style="position: absolute; left:%d; top:%d">\n'%(1,12))
    f.write(str(round(lalo[0],4))+' '+str(round(lalo[1],4))+'\n')
    f.write('</div>\n')
    f.write('</html>\n')
    f.close

def kartta1(x,y,n,korjaus,lalo):
    kartta2(x,y,x+n*Tsize_orig,y+n*Tsize_orig,korjaus,lalo)


def kartta(lat,lon,n):
    y,x=swecoord.wgsToswe(lat,lon)
    xd=int((int(x)%Tsize_orig)/(Tsize_orig/Tsize_pic))
    yd=int((int(y)%Tsize_orig)/(Tsize_orig/Tsize_pic))
    x=int(x)/Tsize_orig*Tsize_orig-int(n/2)*Tsize_orig
    y=int(y)/Tsize_orig*Tsize_orig-int(n/2)*Tsize_orig
    kartta1(x,y,n,(xd,yd),(la,lo))


if __name__ == '__main__':
    la=59.32082918
    lo=18.080272
    bookmarks={'Tuk':(59.32082918,18.080272),'t1':(60.,18.)}
    anna=3
    ONLINE=True
    if os.path.exists(asetukset):
        execfile(asetukset)
    kursori='/mnt/sdcard/karttoja/kursori.png'
    key = '?'
    while key != "q":
	if key == 'g':
	    droid.startLocating()
	    loc = {}
	    while loc == {}:
		loc = droid.readLocation().result
	    try:
		n = loc['gps']
	    except KeyError:
		n = loc['network']
	    la = n['latitude']
	    lo = n['longitude']
	    droid.stopLocating()
        kartta(la,lo,anna)
        os.system('busybox clear')
        droid.viewHtml(kartanpaikka)
        if ONLINE:
            print "** ONLINE **"
        print "Zoom=",anna," la,lo=",round(la,4),',',round(lo,4)
	print 'Left Right Up Down Gps Bookmarks Jump Wider Narrow OffLine Zoomin Quit?'
        delta=anna*360./40000/3*2
        key=getkey()
        if key=="z":
            anna=3
        if key=="o":
            print 'Online Yes No?:'
            key=getkey()
            if key=="y":
                ONLINE=True
            if key=="n":
                ONLINE=False                
        if key=="w":
            anna=anna*2
            if anna>12:
                ONLINE=False
        if key=="n":
            if anna>3:
                anna=anna/2
        if key=="r":
            lo=lo+2*delta
        if key=="l":
            lo=lo-2*delta
        if key=="u":
            la=la+delta
        if key=="d":
            la=la-delta
        if key=="j":
	    la=float(raw_input('Lat:'))
	    lo=float(raw_input('Lon:'))
        if key=="b":
            print 'Add, Retrieve?'
            key=getkey()
            if key=='a':
                nimi=raw_input('nimi?')
                bookmarks[nimi]=(la,lo)
            if key=='r':
                for ni in bookmarks:
                    print ni
                nimi=raw_input('nimi?')
                if nimi in bookmarks:
                    la,lo=bookmarks[nimi]
    f=open(asetukset,'w')
    f.write('la = '+str(la)+'\n')
    f.write('lo = '+str(lo)+'\n')
    f.write('bookmarks = '+str(bookmarks)+'\n')
    f.write('anna = '+str(anna)+'\n')
    f.write('ONLINE = '+str(ONLINE)+'\n')
    f.close()
    
